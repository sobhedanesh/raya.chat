
      window.RAYCHAT_TOKEN = "0dbfd679-66f2-466d-9b03-f5363610aef8"; 
      window.LOAD_TYPE = "FAST_LOAD";
      window.RAYCHAT_WIDGET_LANG = "fa";
      (function() {
        var d = document, s = d.createElement('script');
        s.src = "https://widget-react.raychat.io/install/widget.js";
        s.async = 1;
        d.head.appendChild(s);
      })();
    